package com.example.calmshibainuangryshibainu

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // variables
        val button     = findViewById<Button>(R.id.button)
        val button2    = findViewById<Button>(R.id.button2)
        val imageView  = findViewById<ImageView>(R.id.imageView)
        val imageView2 = findViewById<ImageView>(R.id.imageView)
        val text       = "Gimme Gimme More... FOOD!"
        val text2      = "You best get yo' self away!"
        // button 1's display
        button.setOnClickListener(View.OnClickListener {
            Toast.makeText(applicationContext, text, Toast.LENGTH_SHORT).show()
            imageView.setImageResource(R.drawable.calm_3_50_1_35)
        })
        // button 2's display
        button2.setOnClickListener(View.OnClickListener {
            Toast.makeText(applicationContext, text2, Toast.LENGTH_SHORT).show()
            imageView2.setImageResource(R.drawable.angry_2_40_2_49)
        })
    }
}