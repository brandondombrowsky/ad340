package com.example.clickcounter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    // global variables
    var num = 0
    val duration = Toast.LENGTH_SHORT
    var value = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // increment the value with the touch of a button
        val increment: TextView = findViewById(R.id.button2)
        increment.setOnClickListener {
            num++
            val toast = Toast.makeText(applicationContext, num.toString(), duration)
            toast.setText("Increment: $value, new total is $num")
            toast.show()
        }

        // increment the value with the touch of a button
        val decrement: TextView = findViewById(R.id.button4)
        decrement.setOnClickListener {
            num--
            val toast = Toast.makeText(applicationContext, num.toString(), duration)
            toast.setText("Decrement: $value, new total is $num")
            toast.show()
        }

        // increment the value with the touch of a button
        val reset: TextView = findViewById(R.id.button5)
        reset.setOnClickListener {
            var beforeReset = num
            num = 0
            val toast = Toast.makeText(applicationContext, num.toString(), duration)
            toast.setText("Reset: Original total $beforeReset, new total $num")
            toast.show()
        }
    }
}

