package com.example.clickcounterwithdatabinding

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import com.example.clickcounterwithdatabinding.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    // global variables
    var num = 0
    val duration = Toast.LENGTH_SHORT
    var value = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding: ActivityMainBinding = DataBindingUtil.setContentView(
            this, R.layout.activity_main)

        // increment the value with the touch of a button
        binding.button2.setOnClickListener {
            num++
            val toast = Toast.makeText(applicationContext, num.toString(), duration)
            toast.setText("Increment: $value, new total is $num")
            toast.show()
        }

        // increment the value with the touch of a button
        binding.button4.setOnClickListener {
            num--
            val toast = Toast.makeText(applicationContext, num.toString(), duration)
            toast.setText("Decrement: $value, new total is $num")
            toast.show()
        }

        // increment the value with the touch of a button
        binding.button5.setOnClickListener {
            var beforeReset = num
            num = 0
            val toast = Toast.makeText(applicationContext, num.toString(), duration)
            toast.setText("Reset: Original total $beforeReset, new total $num")
            toast.show()
        }
    }
}

